package com.example.projet_pfe_android;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Generales extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_generales);
    }
}
